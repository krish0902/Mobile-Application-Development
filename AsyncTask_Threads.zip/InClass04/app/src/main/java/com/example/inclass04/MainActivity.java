/*
 Assignment # InClass04
 File name : MainActivity.java
 Full name : Sai Krishna Kattari  (801164930)
 Full name : Kumar Mani Chandra Yelisetty  (801168244)
 Group no  : 17
 */

package com.example.inclass04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private ProgressBar progressBar;
    private SeekBar seekBar;
    private TextView tv_complexity;
    private TextView tv_min;
    private TextView tv_max;
    private TextView tv_average;
    private TextView textView;
    private TextView textView4;
    private TextView textView6;
    private TextView textView8;
    private Button button_calc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = findViewById(R.id.seekBar);
        tv_complexity =findViewById(R.id.tv_complexity);
        tv_min= findViewById(R.id.tv_min);
        tv_max=findViewById(R.id.tv_max);
        tv_average=findViewById(R.id.tv_average);
        textView=findViewById(R.id.textView);
        textView4=findViewById(R.id.textView4);
        textView6=findViewById(R.id.textView6);
        textView8=findViewById(R.id.textView8);

        button_calc =findViewById(R.id.button);

        tv_complexity.setText(1+" Times");


        progressBar = findViewById(R.id.progressBar);
    seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            tv_complexity.setText(progress+" Times");
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {


        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {



        }
    });

        button_calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int complexity = seekBar.getProgress();
                new GetNumbers().execute(complexity);
            }
        });

    }
    void setContainerVisibility(int visibilityStatus){
        if (visibilityStatus==ProgressBar.VISIBLE){
            tv_complexity.setVisibility(TextView.INVISIBLE);
            tv_average.setVisibility(TextView.INVISIBLE);
            tv_max.setVisibility(TextView.INVISIBLE);
            tv_min.setVisibility(TextView.INVISIBLE);
            textView.setVisibility(TextView.INVISIBLE);
            textView4.setVisibility(TextView.INVISIBLE);
            textView6.setVisibility(TextView.INVISIBLE);
            textView8.setVisibility(TextView.INVISIBLE);
            seekBar.setVisibility(SeekBar.INVISIBLE);
            button_calc.setVisibility(Button.INVISIBLE);
            // set progress bar to visible and other invisible
        }
        else if(visibilityStatus==ProgressBar.INVISIBLE)
        {
            tv_complexity.setVisibility(TextView.VISIBLE);
            tv_average.setVisibility(TextView.VISIBLE);
            tv_max.setVisibility(TextView.VISIBLE);
            tv_min.setVisibility(TextView.VISIBLE);
            textView.setVisibility(TextView.VISIBLE);
            textView4.setVisibility(TextView.VISIBLE);
            textView6.setVisibility(TextView.VISIBLE);
            textView8.setVisibility(TextView.VISIBLE);
            seekBar.setVisibility(SeekBar.VISIBLE);
            button_calc.setVisibility(Button.VISIBLE);
        }
    }

    class GetNumbers extends AsyncTask<Integer,Void, ArrayList<Double>> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(ProgressBar.VISIBLE);
            setContainerVisibility(ProgressBar.VISIBLE);
        }

        @Override
        protected ArrayList<Double> doInBackground(Integer... integers) {

            return HeavyWork.getArrayNumbers(integers[0]);
        }

        @Override
        protected void onPostExecute(ArrayList<Double> doubles) {
            super.onPostExecute(doubles);
            Log.d("demo","onPostExecute: "+doubles.toString());
            progressBar.setVisibility(ProgressBar.INVISIBLE);
            setContainerVisibility(ProgressBar.INVISIBLE);

            Double min=findMin(doubles);
            Double max=findMax(doubles);
            Double average=findAvg(doubles);

            tv_min.setText(min+"");
            tv_max.setText(max+"");
            tv_average.setText(average+"");

        }



    }

    private double findMin(ArrayList<Double> doubles)
    {
        double min =Double.MAX_VALUE;

        for(double d: doubles)
        {
            if(min > d)
            {
                min =d;
            }
        }
        return min;
    }

    private double findMax(ArrayList<Double> doubles)
    {
        double max =Double.MIN_VALUE;

        for(double d: doubles)
        {
            if(max < d)
            {
                max =d;
            }
        }
        return max;
    }

    private double findAvg(ArrayList<Double> doubles)
    {
        double sum=0.0;
        double count =0.0;

        for(double d:doubles)
        {
            count++;
            sum+=d;
        }

        return sum/count;
    }


}
