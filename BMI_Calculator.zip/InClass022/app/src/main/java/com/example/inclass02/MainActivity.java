// Assignment # InClass02
// File name : MainActivity.java
// Full name : Sai Krishna Kattari  (801164930)
// Full name : Kumar Mani Chandra Yelisetty  (801168244)
// Group no  : 17

package com.example.inclass02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText et_weight;
    private EditText et_height_feet;
    private EditText et_height_inches;

    private TextView tv_result;
    private TextView tv_verdict;

    private Button button_calculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final double[] weight = {0.0};
        final int[] feet = {0};
        final int[] inches = {0};

        et_weight = findViewById(R.id.et_weight);
        et_height_feet = findViewById(R.id.et_height_feet);
        et_height_inches = findViewById(R.id.et_height_inches);

        tv_result = findViewById(R.id.tv_result);
        tv_verdict = findViewById(R.id.tv_verdict);

        button_calculate = findViewById(R.id.button_calculate);


        button_calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight_text = et_weight.getText().toString();
                String feet_text = et_height_feet.getText().toString();
                String inches_text = et_height_inches.getText().toString();

                int flag = 0;

                if (weight_text.equals("") || weight_text.equals(".")) {
                    et_weight.setError("Invalid Inputs");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    flag = 1;
                } else {
                    weight[0] = Double.parseDouble(weight_text);

                }
                if (feet_text.equals("")) {
                    et_height_feet.setError("Invalid Inputs");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    flag = 1;
                } else {

                    feet[0] = Integer.parseInt(feet_text);
                }
                if (inches_text.equals("")) {
                    et_height_inches.setError("Invalid Inputs");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    flag = 1;
                } else {
                    inches[0] = Integer.parseInt(inches_text);

                }
                if (feet[0] == 0 && inches[0]== 0)
                {
                    et_height_feet.setError("Invalid Inputs");
                    et_height_inches.setError("Invalid Inputs");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    flag = 1;
                }

                if (flag == 0) {

                    et_height_feet.setError(null);
                    et_height_inches.setError(null);

                    inches[0] = inches[0] + feet[0] * 12;

                    double result = (weight[0] / (inches[0] * inches[0])) * 703;

                    double bmi = Math.round((result * 10)) / 10.0;

                    tv_result.setText("Your BMI: " + bmi);

                    Log.d("demo", "weight" + weight[0] + "feet" + feet[0] + "inches" + inches[0]);


                    Toast.makeText(MainActivity.this, "BMI Calculated", Toast.LENGTH_SHORT).show();

                    if (bmi < 18.5) {
                        tv_verdict.setText("You are Underweight");

                    } else if (bmi >= 18.5 && bmi <= 24.9) {
                        tv_verdict.setText("You are Normal");

                    } else if (bmi > 24.9 && bmi <= 29.9) {
                        tv_verdict.setText("You are overweight");

                    } else if (bmi > 29.9) {
                        tv_verdict.setText("You are obese");

                    }


                }
                else
                {
                    tv_result.setText("Your BMI: " );
                    tv_verdict.setText("");
                }
            }

        });

    }
}
