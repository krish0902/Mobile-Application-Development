package com.example.inclass03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayMyProfileActivity extends AppCompatActivity {

    TextView tv_name;
    TextView tv_gender;
    Button bt_edit;
    ImageView iv_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_my_profile);

        tv_name = findViewById(R.id.tv_name);
        tv_gender =findViewById(R.id.tv_gender);
        bt_edit  =findViewById(R.id.bt_edit);
        iv_result = findViewById(R.id.iv_result);

        setTitle("Display Profile");

        if(getIntent() != null && getIntent().getExtras() !=null)
        {

            User user=(User) getIntent().getExtras().getSerializable(MainActivity.USER_KEY);

            tv_name.setText("Name: "+user.firstName+" "+user.lastName);

            tv_gender.setText(user.gender);

            if(user.gender.equals("Female"))
            {
                iv_result.setImageDrawable(getDrawable(R.drawable.female));
            }
            else if(user.gender.equals("Male"))
            {
                iv_result.setImageDrawable(getDrawable(R.drawable.male));
            }

        }

        bt_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
