/*
 Assignment # InClass03
 File name : MainActivity.java
 Full name : Sai Krishna Kattari  (801164930)
 Full name : Kumar Mani Chandra Yelisetty  (801168244)
 Group no  : 17
 */

package com.example.inclass03;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_CODE =0x001;
    static String USER_KEY ="USER";

    ImageView iv_avatar;
    EditText et_firstname;
    EditText et_lastname;
    Button bt_save;
    int flag2=0;

    static String gender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_firstname = findViewById(R.id.et_firstname);
        et_lastname = findViewById(R.id.et_lastname);
        iv_avatar = findViewById(R.id.iv_avatar);

        flag2 = 0;

          iv_avatar.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Intent toSelectAvatar = new Intent(MainActivity.this,SelectAvatar.class);
                  startActivityForResult(toSelectAvatar, REQ_CODE);
                  flag2 =1;
              }
          });

        bt_save = findViewById(R.id.bt_save);

        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String firstname = et_firstname.getText().toString();
                String lastname = et_lastname.getText().toString();

                int flag=0;

                if(firstname.equals(""))
                {
                    et_firstname.setError("Invalid Inputs");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    flag=1;
                }
                if(lastname.equals(""))
                {
                    et_lastname.setError("Invalid Inputs");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    flag=1;
                }
                if(flag2 == 0)
                {
                    Toast.makeText(MainActivity.this, "Please select an Avatar", Toast.LENGTH_SHORT).show();
                }
                if(flag == 0 && flag2 == 1) {
                    Intent toSelectSave = new Intent(MainActivity.this, DisplayMyProfileActivity.class);

                    User user = new User(gender, firstname, lastname);

                    toSelectSave.putExtra(USER_KEY, user);

                    startActivity(toSelectSave);
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == REQ_CODE && resultCode == RESULT_OK && data != null)
        {
            gender = data.getExtras().getString(SelectAvatar.GENDER);

            if(gender.equals("Female"))
            {
                iv_avatar.setImageDrawable(getDrawable(R.drawable.female));
            }
            else
            {
                iv_avatar.setImageDrawable(getDrawable(R.drawable.male));
            }
        }
    }


}
