package com.example.inclass03;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SelectAvatar extends AppCompatActivity implements View.OnClickListener {

    public static final String GENDER = "gender";
    ImageView iv_male,iv_female;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_avatar);

        iv_female =findViewById(R.id.iv_female);
        iv_male =findViewById(R.id.iv_male);

        setTitle("Select Avatar");

      iv_female.setOnClickListener(this);
      iv_male.setOnClickListener(this);
    }

    public void onClick(View view)
    {Intent returnedData = new Intent();
        if(view == iv_female)
        {

            returnedData.putExtra(GENDER, "Female");

            setResult(RESULT_OK, returnedData);
            finish();
        }
        else if(view == iv_male)
        {
            returnedData.putExtra(GENDER, "Male");

            setResult(RESULT_OK, returnedData);
            finish();
        }



    }

}
