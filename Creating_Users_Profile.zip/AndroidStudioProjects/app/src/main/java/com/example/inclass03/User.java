package com.example.inclass03;
import java.io.Serializable;

public class User implements Serializable{

    String gender;
    String firstName;
    String lastName;

    public String getFirstName() {
        return firstName;
    }

    public User(String gender, String firstName, String lastName) {
        this.gender = gender;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGender() {
        return gender;
    }

    public User(String gender) {
        this.gender = gender;
    }
}
